# MyNewDatabaseGrid
Javascript grid for MySql database configurable, editable and sortable
